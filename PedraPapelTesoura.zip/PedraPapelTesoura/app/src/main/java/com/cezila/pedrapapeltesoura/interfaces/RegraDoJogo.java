package com.cezila.pedrapapeltesoura.interfaces;

import com.cezila.pedrapapeltesoura.enums.Jogada;
import com.cezila.pedrapapeltesoura.enums.Resultado;

public interface RegraDoJogo {

    Resultado definirGanhador(Jogada jogador, Jogada maquina);

    Jogada gerarJogadaMaquina();

}
