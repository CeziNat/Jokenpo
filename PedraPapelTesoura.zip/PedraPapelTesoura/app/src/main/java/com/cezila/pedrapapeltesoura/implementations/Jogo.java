package com.cezila.pedrapapeltesoura.implementations;

import android.util.Log;

import com.cezila.pedrapapeltesoura.enums.Jogada;
import com.cezila.pedrapapeltesoura.enums.Resultado;
import com.cezila.pedrapapeltesoura.interfaces.RegraDoJogo;

public class Jogo implements RegraDoJogo {

    @Override
    public Resultado definirGanhador(Jogada jogador, Jogada maquina) {
        if (jogador == maquina) {
            return Resultado.EMPATE;
        }

        if (
                jogador == Jogada.PAPEL && maquina == Jogada.PEDRA ||
                        jogador == Jogada.PEDRA && maquina == Jogada.TESOURA ||
                        jogador == Jogada.TESOURA && maquina == Jogada.PAPEL
        ) {
            return Resultado.USUARIO;
        }

        return Resultado.MAQUINA;
    }

    @Override
    public Jogada gerarJogadaMaquina() {
        int numeroAleatorio = (int)(Math.random() * 3); // 0..2
        Log.d("##Jogo", "Numero aleatorio: " + numeroAleatorio);
        switch (numeroAleatorio) {
            case 0:
                Log.d("##Jogo", "Retornamos pedra");
                return Jogada.PEDRA;
            case 1:
                Log.d("##Jogo", "Retornamos papel");
                return Jogada.PAPEL;
            default:
                Log.d("##Jogo", "Retornamos tesoura");
                return Jogada.TESOURA;
        }
    }

}
