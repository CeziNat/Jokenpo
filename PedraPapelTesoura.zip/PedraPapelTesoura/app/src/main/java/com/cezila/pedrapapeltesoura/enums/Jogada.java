package com.cezila.pedrapapeltesoura.enums;

public enum Jogada {
    PEDRA,
    PAPEL,
    TESOURA
}
