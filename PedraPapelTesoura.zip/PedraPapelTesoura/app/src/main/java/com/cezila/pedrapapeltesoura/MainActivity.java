package com.cezila.pedrapapeltesoura;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.cezila.pedrapapeltesoura.enums.Jogada;
import com.cezila.pedrapapeltesoura.enums.Resultado;
import com.cezila.pedrapapeltesoura.implementations.Jogo;

public class MainActivity extends AppCompatActivity {

    Jogo jogo = new Jogo();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView ivPedra = findViewById(R.id.iv_pedra);
        ImageView ivPapel = findViewById(R.id.iv_papel);
        ImageView ivTesoura = findViewById(R.id.iv_tesoura);
        ImageView ivJogadaJogador = findViewById(R.id.iv_jogada_jogador);
        ImageView ivJogadaMaquina = findViewById(R.id.iv_jogada_maquina);
        TextView tvResultado = findViewById(R.id.tv_resultado);

        ivPedra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Jogada jogadaMaquina = jogo.gerarJogadaMaquina();
                Resultado resultado = jogo.definirGanhador(Jogada.PEDRA, jogadaMaquina);

                ivJogadaJogador.setImageResource(R.drawable.pedra);

                Log.d("##MainActivity", "Resultado ao clicar em pedra: " + resultado.name());

                switch (jogadaMaquina) {
                    case PEDRA:
                        ivJogadaMaquina.setImageResource(R.drawable.pedra);
                        break;
                    case PAPEL:
                        ivJogadaMaquina.setImageResource(R.drawable.papel);
                        break;
                    case TESOURA:
                        ivJogadaMaquina.setImageResource(R.drawable.tesoura);
                        break;
                }

                String mensagemDeResultado = gerarMensagem(resultado);
                tvResultado.setText(mensagemDeResultado);
            }
        });

        ivPapel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Jogada jogadaMaquina = jogo.gerarJogadaMaquina();
                Resultado resultado = jogo.definirGanhador(Jogada.PAPEL, jogadaMaquina);

                ivJogadaJogador.setImageResource(R.drawable.papel);

                Log.d("##MainActivity", "Resultado ao clicar em papel: " + resultado.name());

                switch (jogadaMaquina) {
                    case PEDRA:
                        ivJogadaMaquina.setImageResource(R.drawable.pedra);
                        break;
                    case PAPEL:
                        ivJogadaMaquina.setImageResource(R.drawable.papel);
                        break;
                    case TESOURA:
                        ivJogadaMaquina.setImageResource(R.drawable.tesoura);
                        break;
                }

                String mensagemDeResultado = gerarMensagem(resultado);
                tvResultado.setText(mensagemDeResultado);
            }
        });

        ivTesoura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Jogada jogadaMaquina = jogo.gerarJogadaMaquina();
                Resultado resultado = jogo.definirGanhador(Jogada.TESOURA, jogadaMaquina);

                ivJogadaJogador.setImageResource(R.drawable.tesoura);

                Log.d("##MainActivity", "Resultado ao clicar em tesoura: " + resultado.name());

                switch (jogadaMaquina) {
                    case PEDRA:
                        ivJogadaMaquina.setImageResource(R.drawable.pedra);
                        break;
                    case PAPEL:
                        ivJogadaMaquina.setImageResource(R.drawable.papel);
                        break;
                    case TESOURA:
                        ivJogadaMaquina.setImageResource(R.drawable.tesoura);
                        break;
                }

                String mensagemDeResultado = gerarMensagem(resultado);
                tvResultado.setText(mensagemDeResultado);
            }
        });
    }

    private String gerarMensagem(Resultado resultado) {
        switch (resultado) {
            case USUARIO:
                return "Parabéns, você venceu!";
            case MAQUINA:
                return "Que azar, você perdeu!";
            case EMPATE:
                return "Empate!";
        }
        return "";
    }

}