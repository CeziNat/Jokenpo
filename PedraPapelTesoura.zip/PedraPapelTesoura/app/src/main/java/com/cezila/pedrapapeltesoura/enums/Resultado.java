package com.cezila.pedrapapeltesoura.enums;

public enum Resultado {
    USUARIO,
    MAQUINA,
    EMPATE
}
